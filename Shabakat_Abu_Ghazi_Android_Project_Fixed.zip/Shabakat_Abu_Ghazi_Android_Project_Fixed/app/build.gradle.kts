plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ye.abughazi.network"
    compileSdk = 35
    defaultConfig {
        applicationId = "ye.abughazi.network"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "0.1"
        
        compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

kotlin {
    jvmToolchain(17)
}
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
kotlin {
    jvmToolchain(17)
}
